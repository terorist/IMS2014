
SIMLIB/C++ demo examples - tutorial

All basic parts of SIMLIB are tested by simple simulation models

- SIMLIB should be compiled in ../src directory
- use "make run" or "gmake run" to test all examples  
- go to reference-outputs directory and compare outputs
- usable for regression-testing of new SIMLIB versions

TODO:
- convert all comments to english
- all Makefile.*-- needs work
- add more examples

